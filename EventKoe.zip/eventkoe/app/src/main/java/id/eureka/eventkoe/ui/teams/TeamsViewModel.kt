package id.eureka.eventkoe.ui.teams

import androidx.lifecycle.ViewModel

class TeamsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}