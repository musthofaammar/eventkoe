package id.eureka.dotakoe.core.domain.usecase

class TeamIteractor {

}